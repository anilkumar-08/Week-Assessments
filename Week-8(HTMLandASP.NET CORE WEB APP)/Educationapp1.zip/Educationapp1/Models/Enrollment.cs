﻿using System;
using System.Collections.Generic;

namespace Educationapp1.Models;

public partial class Enrollment
{
    public int Enrollmentid { get; set; }

    public DateTime? Enrollmentdate { get; set; }

    public int? Studentid { get; set; }

    public int? Courseid { get; set; }

    public int? Universityid { get; set; }

    public virtual Course? Course { get; set; }

    public virtual Student? Student { get; set; }

    public virtual University? University { get; set; }
}
