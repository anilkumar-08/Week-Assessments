﻿using Microsoft.AspNetCore.Mvc.Rendering;

namespace Educationapp1.Models
{
    public class StudentSelection
    {
        public List<Student>? Students { get; set; }
        public SelectList? Studentaddresses { get; set; }
        public string? StudentAddress { get; set; }
        public string? SearchString { get; set; }
    }
}

