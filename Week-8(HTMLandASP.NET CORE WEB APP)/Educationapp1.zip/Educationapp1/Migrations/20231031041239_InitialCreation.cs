﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Educationapp1.Migrations
{
    /// <inheritdoc />
    public partial class InitialCreation : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Course",
                columns: table => new
                {
                    Courseid = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Coursetitle = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: true),
                    CoursestartDate = table.Column<DateTime>(type: "date", nullable: true),
                    Courseprice = table.Column<decimal>(type: "money", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__Course__C9D27D8F3069B109", x => x.Courseid);
                });

            migrationBuilder.CreateTable(
                name: "Student",
                columns: table => new
                {
                    Studentid = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Studentname = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    Studentaddress = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    Studentphone = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    Studentemail = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__Student__32CE55B1851B0322", x => x.Studentid);
                });

            migrationBuilder.CreateTable(
                name: "University",
                columns: table => new
                {
                    Universityid = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Universityname = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    Universitystate = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    Universitycity = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    Universityphone = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    Universityemail = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: true),
                    Universityfee = table.Column<decimal>(type: "money", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__Universi__9F1EC514A79526C7", x => x.Universityid);
                });

            migrationBuilder.CreateTable(
                name: "Enrollment",
                columns: table => new
                {
                    Enrollmentid = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Enrollmentdate = table.Column<DateTime>(type: "date", nullable: true),
                    Studentid = table.Column<int>(type: "int", nullable: true),
                    Courseid = table.Column<int>(type: "int", nullable: true),
                    Universityid = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__Enrollme__7F657B53F15CA4EC", x => x.Enrollmentid);
                    table.ForeignKey(
                        name: "FK__Enrollmen__Cours__3E52440B",
                        column: x => x.Courseid,
                        principalTable: "Course",
                        principalColumn: "Courseid");
                    table.ForeignKey(
                        name: "FK__Enrollmen__Stude__3D5E1FD2",
                        column: x => x.Studentid,
                        principalTable: "Student",
                        principalColumn: "Studentid");
                    table.ForeignKey(
                        name: "FK__Enrollmen__Unive__3F466844",
                        column: x => x.Universityid,
                        principalTable: "University",
                        principalColumn: "Universityid");
                });

            migrationBuilder.CreateIndex(
                name: "IX_Enrollment_Courseid",
                table: "Enrollment",
                column: "Courseid");

            migrationBuilder.CreateIndex(
                name: "IX_Enrollment_Studentid",
                table: "Enrollment",
                column: "Studentid");

            migrationBuilder.CreateIndex(
                name: "IX_Enrollment_Universityid",
                table: "Enrollment",
                column: "Universityid");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Enrollment");

            migrationBuilder.DropTable(
                name: "Course");

            migrationBuilder.DropTable(
                name: "Student");

            migrationBuilder.DropTable(
                name: "University");
        }
    }
}
