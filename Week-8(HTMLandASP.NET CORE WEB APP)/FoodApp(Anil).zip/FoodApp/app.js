$(document).ready(function() {
    // Define your food data in an array
    const foods = [
        { title: "Food 1", price: "$10", description: "Description 1", category: "veg" },
        { title: "Food 2", price: "$12", description: "Description 2", category: "nonveg" },
        { title: "Food 3", price: "$8", description: "Description 3", category: "beverages" }
        // Add more food items as needed
    ];

    function displayFood(category) {
        $("#foodList").empty();
        const categoryFoods = foods.filter(food => food.category === category);
        categoryFoods.forEach(food => {
            $("#foodList").append(`<div class="card mb-3">
                <div class="card-body">
                    <h5 class="card-title">${food.title}</h5>
                    <p class="card-text">Price: ${food.price}</p>
                    <p class="card-text">${food.description}</p>
                </div>
            </div>`);
        });
    }

    $("#categories a").click(function() {
        const category = $(this).data("category");
        displayFood(category);
    });
});
