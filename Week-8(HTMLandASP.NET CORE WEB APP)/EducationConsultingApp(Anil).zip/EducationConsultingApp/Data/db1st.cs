﻿using System;
using System.Collections.Generic;
using EducationConsultingApp.Models;
using Microsoft.EntityFrameworkCore;

namespace EducationConsultingApp.Data;

public partial class db1st : DbContext
{
    public db1st()
    {
    }

    public db1st(DbContextOptions<db1st> options)
        : base(options)
    {
    }

    public virtual DbSet<Course> Courses { get; set; }

    public virtual DbSet<Enrollment> Enrollments { get; set; }

    public virtual DbSet<Student> Students { get; set; }

    public virtual DbSet<University> Universities { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=Educationdb.Data;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Course>(entity =>
        {
            entity.HasKey(e => e.Courseid).HasName("PK__Course__C9D27D8F9B38137E");

            entity.ToTable("Course");

            entity.Property(e => e.Courseid).ValueGeneratedNever();
            entity.Property(e => e.Courseprice).HasColumnType("money");
            entity.Property(e => e.CoursestartDate).HasColumnType("date");
            entity.Property(e => e.Coursetitle)
                .HasMaxLength(20)
                .IsUnicode(false);
        });

        modelBuilder.Entity<Enrollment>(entity =>
        {
            entity.HasKey(e => e.Enrollmentid).HasName("PK__Enrollme__7F657B5333BA0E51");

            entity.ToTable("Enrollment");

            entity.Property(e => e.Enrollmentid).ValueGeneratedNever();
            entity.Property(e => e.Enrollmentdate).HasColumnType("date");

            entity.HasOne(d => d.Course).WithMany(p => p.Enrollments)
                .HasForeignKey(d => d.Courseid)
                .HasConstraintName("FK__Enrollmen__Cours__2B3F6F97");

            entity.HasOne(d => d.Student).WithMany(p => p.Enrollments)
                .HasForeignKey(d => d.Studentid)
                .HasConstraintName("FK__Enrollmen__Stude__2A4B4B5E");

            entity.HasOne(d => d.University).WithMany(p => p.Enrollments)
                .HasForeignKey(d => d.Universityid)
                .HasConstraintName("FK__Enrollmen__Unive__2C3393D0");
        });

        modelBuilder.Entity<Student>(entity =>
        {
            entity.HasKey(e => e.Studentid).HasName("PK__Student__32CE55B1E41ECE38");

            entity.ToTable("Student");

            entity.Property(e => e.Studentid).ValueGeneratedNever();
            entity.Property(e => e.Studentaddress)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.Studentemail)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.Studentname)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.Studentphone)
                .HasMaxLength(10)
                .IsUnicode(false);
        });

        modelBuilder.Entity<University>(entity =>
        {
            entity.HasKey(e => e.Universityid).HasName("PK__Universi__9F1EC5141920B6A0");

            entity.ToTable("University");

            entity.Property(e => e.Universityid).ValueGeneratedNever();
            entity.Property(e => e.Universityaddress)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.Universityemail)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.Universityfee).HasColumnType("money");
            entity.Property(e => e.Universityname)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.Universityphone)
                .HasMaxLength(10)
                .IsUnicode(false);
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
