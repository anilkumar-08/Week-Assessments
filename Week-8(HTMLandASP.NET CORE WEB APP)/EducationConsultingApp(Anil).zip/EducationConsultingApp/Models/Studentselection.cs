﻿using Microsoft.AspNetCore.Mvc.Rendering;

namespace EducationConsultingApp.Models
{
    public class Studentselection
    {
        public List<Student>? Students { get; set; }
        public SelectList? Studentaddresses { get; set; }
        public string? StudentAddress { get; set; }
        public string? SearchString { get; set; }
    }
}
