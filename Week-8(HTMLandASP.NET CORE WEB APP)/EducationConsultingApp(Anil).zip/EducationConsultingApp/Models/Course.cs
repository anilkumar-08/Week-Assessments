﻿using System;
using System.Collections.Generic;

namespace EducationConsultingApp.Models;

public partial class Course
{
    public int Courseid { get; set; }

    public string? Coursetitle { get; set; }

    public DateTime? CoursestartDate { get; set; }

    public decimal? Courseprice { get; set; }

    public virtual ICollection<Enrollment> Enrollments { get; set; } = new List<Enrollment>();
}
