﻿using System;
using System.Collections.Generic;

namespace EducationConsultingApp.Models;

public partial class Student
{
    public int Studentid { get; set; }

    public string? Studentname { get; set; }

    public string? Studentaddress { get; set; }

    public string? Studentphone { get; set; }

    public string? Studentemail { get; set; }

    public virtual ICollection<Enrollment> Enrollments { get; set; } = new List<Enrollment>();
}
