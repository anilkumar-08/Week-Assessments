﻿using System;
using System.Collections.Generic;

namespace EducationConsultingApp.Models;

public partial class University
{
    public int Universityid { get; set; }

    public string? Universityname { get; set; }

    public string? Universityaddress { get; set; }

    public string? Universityphone { get; set; }

    public string? Universityemail { get; set; }

    public decimal? Universityfee { get; set; }

    public virtual ICollection<Enrollment> Enrollments { get; set; } = new List<Enrollment>();
}
