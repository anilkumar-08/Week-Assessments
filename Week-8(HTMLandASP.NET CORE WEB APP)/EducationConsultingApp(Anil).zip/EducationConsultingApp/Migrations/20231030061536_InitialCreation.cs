﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace EducationConsultingApp.Migrations
{
    /// <inheritdoc />
    public partial class InitialCreation : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Course",
                columns: table => new
                {
                    Courseid = table.Column<int>(type: "int", nullable: false),
                    Coursetitle = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: true),
                    CoursestartDate = table.Column<DateTime>(type: "date", nullable: true),
                    Courseprice = table.Column<decimal>(type: "money", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__Course__C9D27D8F9B38137E", x => x.Courseid);
                });

            migrationBuilder.CreateTable(
                name: "Student",
                columns: table => new
                {
                    Studentid = table.Column<int>(type: "int", nullable: false),
                    Studentname = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    Studentaddress = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    Studentphone = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    Studentemail = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__Student__32CE55B1E41ECE38", x => x.Studentid);
                });

            migrationBuilder.CreateTable(
                name: "University",
                columns: table => new
                {
                    Universityid = table.Column<int>(type: "int", nullable: false),
                    Universityname = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    Universityaddress = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    Universityphone = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    Universityemail = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: true),
                    Universityfee = table.Column<decimal>(type: "money", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__Universi__9F1EC5141920B6A0", x => x.Universityid);
                });

            migrationBuilder.CreateTable(
                name: "Enrollment",
                columns: table => new
                {
                    Enrollmentid = table.Column<int>(type: "int", nullable: false),
                    Enrollmentdate = table.Column<DateTime>(type: "date", nullable: true),
                    Studentid = table.Column<int>(type: "int", nullable: true),
                    Courseid = table.Column<int>(type: "int", nullable: true),
                    Universityid = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__Enrollme__7F657B5333BA0E51", x => x.Enrollmentid);
                    table.ForeignKey(
                        name: "FK__Enrollmen__Cours__2B3F6F97",
                        column: x => x.Courseid,
                        principalTable: "Course",
                        principalColumn: "Courseid");
                    table.ForeignKey(
                        name: "FK__Enrollmen__Stude__2A4B4B5E",
                        column: x => x.Studentid,
                        principalTable: "Student",
                        principalColumn: "Studentid");
                    table.ForeignKey(
                        name: "FK__Enrollmen__Unive__2C3393D0",
                        column: x => x.Universityid,
                        principalTable: "University",
                        principalColumn: "Universityid");
                });

            migrationBuilder.CreateIndex(
                name: "IX_Enrollment_Courseid",
                table: "Enrollment",
                column: "Courseid");

            migrationBuilder.CreateIndex(
                name: "IX_Enrollment_Studentid",
                table: "Enrollment",
                column: "Studentid");

            migrationBuilder.CreateIndex(
                name: "IX_Enrollment_Universityid",
                table: "Enrollment",
                column: "Universityid");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Enrollment");

            migrationBuilder.DropTable(
                name: "Course");

            migrationBuilder.DropTable(
                name: "Student");

            migrationBuilder.DropTable(
                name: "University");
        }
    }
}
